/**
 * Fastwo TN — Auth API (WhatsApp OTP)
 *
 * Endpoints (consumed by frontend/index.html):
 *   POST /api/auth/send-otp    { phone, name? }      -> sends 4-digit OTP via WhatsApp
 *   POST /api/auth/verify-otp  { phone, code, name? }-> verifies, creates session
 *   GET  /api/auth/me          (Bearer <token>)      -> returns current user
 *   POST /api/auth/logout      (Bearer <token>)      -> destroys session
 *
 * Requires Supabase tables from supabase/schema.sql.
 * Meta WhatsApp token stays ONLY on this server.
 */
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const { createClient } = require('@supabase/supabase-js');

const PORT = Number(process.env.PORT || 3001);
const SESSION_TTL_MS = Number(process.env.SESSION_TTL_MS || 30 * 24 * 60 * 60 * 1000);
const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_MAX_ATTEMPTS = 5;

const app = express();
app.use(express.json());

const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    // Allow non-browser clients (curl, mobile) and listed origins
    if (!origin || allowed.length === 0 || allowed.includes(origin)) return cb(null, true);
    cb(new Error('Origin not allowed: ' + origin));
  }
}));

const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_ROLE_KEY || ''
);

// ---------- helpers ----------

function normPhone(phone) {
  let p = String(phone || '').replace(/\D/g, '');
  if (p.length === 8) p = '216' + p;           // Tunisian local number
  return p;
}

function isValidPhone(p) {
  return /^\d{8,15}$/.test(p);
}

async function getProfile(phone) {
  const { data, error } = await supabase
    .from('profiles')
    .select('phone, name, created_at')
    .eq('phone', phone)
    .maybeSingle();
  if (error) throw error;
  return data;
}

async function sendWhatsAppOtp(phone, code) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneId) {
    console.log(`[DEV] OTP for ${phone}: ${code}  (no WHATSAPP_TOKEN configured)`);
    return { delivered: false };
  }
  const version = process.env.WHATSAPP_API_VERSION || 'v19.0';
  const res = await fetch(`https://graph.facebook.com/${version}/${phoneId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      to: phone,
      type: 'template',
      template: {
        name: 'fastwo_otp',
        language: { code: 'fr' },
        components: [{
          type: 'body',
          parameters: [{ type: 'text', text: code }]
        }]
      }
    })
  });
  if (!res.ok) {
    const body = await res.text();
    console.error('WhatsApp API error:', res.status, body);
    return { delivered: false, error: body };
  }
  return { delivered: true };
}

function bearerToken(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
}

async function sessionUser(req) {
  const token = bearerToken(req);
  if (!token) return null;
  const { data, error } = await supabase
    .from('sessions')
    .select('token, phone, expires_at, profiles(name)')
    .eq('token', token)
    .maybeSingle();
  if (error || !data) return null;
  if (new Date(data.expires_at).getTime() < Date.now()) return null;
  const prof = Array.isArray(data.profiles) ? data.profiles[0] : data.profiles;
  return { name: prof ? prof.name : '', phone: data.phone };
}

// ---------- routes ----------

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'fastwo-auth' }));

app.post('/api/auth/send-otp', async (req, res) => {
  try {
    const phone = normPhone(req.body.phone);
    const name = (req.body.name || '').trim();
    if (!isValidPhone(phone)) {
      return res.status(400).json({ error: 'Numero invalide' });
    }

    const profile = await getProfile(phone);
    if (!profile && !name) {
      return res.status(400).json({ needName: true, error: 'Premiere fois: entrez aussi votre nom' });
    }

    const code = String(crypto.randomInt(1000, 10000));
    const expiresAt = new Date(Date.now() + OTP_TTL_MS).toISOString();

    const { error } = await supabase.from('otp_codes').upsert(
      { phone, code, expires_at: expiresAt, attempts: 0 },
      { onConflict: 'phone' }
    );
    if (error) throw error;

    if (name && !profile) {
      await supabase.from('profiles').insert({ phone, name });
    }

    const wa = await sendWhatsAppOtp(phone, code);
    res.json({
      message: wa.delivered
        ? 'Code envoye sur WhatsApp'
        : 'Code genere (voir console serveur en mode dev)'
    });
  } catch (err) {
    console.error('send-otp error:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.post('/api/auth/verify-otp', async (req, res) => {
  try {
    const phone = normPhone(req.body.phone);
    const code = String(req.body.code || '').replace(/\D/g, '');
    const name = (req.body.name || '').trim();

    const { data: otp, error } = await supabase
      .from('otp_codes')
      .select('*')
      .eq('phone', phone)
      .maybeSingle();
    if (error) throw error;

    if (!otp || new Date(otp.expires_at).getTime() < Date.now()) {
      return res.status(400).json({ error: 'Code expire — demandez un nouveau' });
    }
    if (otp.attempts >= OTP_MAX_ATTEMPTS) {
      return res.status(429).json({ error: 'Trop d essais — demandez un nouveau code' });
    }
    if (otp.code !== code) {
      await supabase.from('otp_codes')
        .update({ attempts: otp.attempts + 1 })
        .eq('phone', phone);
      return res.status(400).json({ error: 'Code incorrect' });
    }

    let profile = await getProfile(phone);
    if (!profile) {
      if (!name) return res.status(400).json({ needName: true, error: 'Entrez votre nom' });
      await supabase.from('profiles').insert({ phone, name });
      profile = { phone, name };
    }

    // One-time code: delete after success
    await supabase.from('otp_codes').delete().eq('phone', phone);

    const token = crypto.randomBytes(32).toString('hex');
    const expiresAtMs = Date.now() + SESSION_TTL_MS;
    await supabase.from('sessions').insert({
      token,
      phone,
      expires_at: new Date(expiresAtMs).toISOString()
    });

    res.json({
      user: { name: profile.name, phone: profile.phone },
      token,
      expiresAt: expiresAtMs
    });
  } catch (err) {
    console.error('verify-otp error:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.get('/api/auth/me', async (req, res) => {
  const user = await sessionUser(req);
  if (!user) return res.status(401).json({ error: 'Session invalide' });
  res.json({ user });
});

app.post('/api/auth/logout', async (req, res) => {
  const token = bearerToken(req);
  if (token) {
    await supabase.from('sessions').delete().eq('token', token);
  }
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Fastwo auth API listening on http://localhost:${PORT}`);
  if (!process.env.WHATSAPP_TOKEN) {
    console.log('WHATSAPP_TOKEN not set — OTP codes will be printed here (dev mode).');
  }
});
